import type { KeyValue } from '../../common';
import type { Graph } from '../../graph';
import type { Edge, TerminalCellData, TerminalType } from '../../model';
import type { CellView } from '../../view';
import { Registry } from '../registry';
import * as strategies from './main';
import type { PointLike } from '../../types';
export type ConnectionStrategyDefinition = (this: Graph, terminal: TerminalCellData, cellView: CellView, magnet: Element, coords: PointLike, edge: Edge, type: TerminalType, options: KeyValue) => TerminalCellData;
type Presets = typeof connectionStrategyPresets;
type NativeNames = keyof Presets;
export interface NativeItem<T extends NativeNames = NativeNames> {
    name: T;
    args?: KeyValue;
}
export interface ManualItem {
    name: Exclude<string, NativeNames>;
    args?: KeyValue;
}
export declare const connectionStrategyPresets: typeof strategies;
export declare const connectionStrategyRegistry: Registry<ConnectionStrategyDefinition, typeof strategies, never>;
export {};
